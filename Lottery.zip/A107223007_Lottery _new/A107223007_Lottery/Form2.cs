﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A107223007_Lottery
{
    public partial class Form2 : Form
    {
        int[] randomArray = new int[5];
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "")
            {
                MessageBox.Show("即將開獎!!");
                lottery obj = new lottery();
                obj.TextBoxMsg = textBox1.Text;//把form1的值設定到form2
                obj.TextBoxMsg1 = textBox2.Text;//把form1的值設定到form2
                obj.TextBoxMsg2 = textBox3.Text;//把form1的值設定到form2
                obj.TextBoxMsg3 = textBox4.Text;//把form1的值設定到form2
                obj.TextBoxMsg4 = textBox5.Text;//把form1的值設定到form2
                this.textBox1.Text = obj.TextBoxMsg;//從form2取值設定到form1
                this.textBox2.Text = obj.TextBoxMsg1;//從form2取值設定到form1
                this.textBox3.Text = obj.TextBoxMsg2;//從form2取值設定到form1
                this.textBox4.Text = obj.TextBoxMsg3;//從form2取值設定到form1
                this.textBox5.Text = obj.TextBoxMsg4;//從form2取值設定到form1
                this.Visible = false;
                obj.Visible = true;
            }
            else
            {
                MessageBox.Show("請選擇5個號碼!");
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            for (int i = 4; i < 52; i++)
            {
                this.Controls["Button" + i.ToString()].Click += new System.EventHandler(this.button3_Click);
            }
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            foreach (Control ctl in this.Controls)
            {
                if (ctl is Button)
                {
                    Button btn = ctl as Button;
                    btn.Enabled = true;
                }
            }
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox4.Enabled = true;
            textBox5.Enabled = true;
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            foreach (Control ctl in this.Controls)
            {
                if (ctl is Button)
                {
                    Button btn = ctl as Button;
                    btn.Enabled = true;
                }
            }
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox4.Enabled = true;
            textBox5.Enabled = true;
           
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.Enabled = false;
            if (textBox1.Text == "")
            {
                textBox1.Text = btn.Tag.ToString();
            }
            else
            {
                if (textBox2.Text == "")
                {
                    textBox2.Text = btn.Tag.ToString();
                }
                else
                {
                    if (textBox3.Text == "")
                    {
                        textBox3.Text = btn.Tag.ToString();
                    }
                    else
                    {
                        if (textBox3.Text == "")
                        {
                            textBox3.Text = btn.Tag.ToString();
                        }
                        else
                        {
                            if (textBox4.Text == "")
                            {
                                textBox4.Text = btn.Tag.ToString();
                            }
                            else
                            {
                                if (textBox5.Text == "")
                                {
                                    textBox5.Text = btn.Tag.ToString();
                                }
                                else
                                {
                                    textBox1.Enabled = false;
                                    textBox2.Enabled = false;
                                    textBox3.Enabled = false;
                                    textBox4.Enabled = false;
                                    textBox5.Enabled = false;
                                }
                                    
                            }
                        }
                    }
                }
            }
        }

        private void button52_Click(object sender, EventArgs e)
        {
            foreach (Control ctl in this.Controls)
            {
                if (ctl is Button)
                {
                    Button btn = ctl as Button;
                    btn.Enabled = false;
                }
            }
            Random r = new Random();
            for (int i = 0; i < randomArray.Length; i++)
            {
                randomArray[i] = r.Next(1, 49);
                for (int j = 0; j < i; j++)
                {
                    while (randomArray[j] == randomArray[i])
                    {
                        j = 0;
                        randomArray[i] = r.Next(1, 49);
                    }
                }
            }
            textBox1.Text = randomArray[0].ToString();
            textBox2.Text = randomArray[1].ToString();
            textBox3.Text = randomArray[2].ToString();
            textBox4.Text = randomArray[3].ToString();
            textBox5.Text = randomArray[4].ToString();
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;
            button1.Enabled = true;
            button2.Enabled = true;
          
        }
    }
}

