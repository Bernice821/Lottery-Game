﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace A107223007_Lottery
{
    //394-38=356 button width
    //385-28=357
    public partial class lottery : Form
    {

        private void timer3_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(2,y);
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(1,y);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(0,y);
        }
        PictureBox[] pb;
        Random r = new Random();
        ImageList ig = new ImageList();
        int[] randomArray = new int[49];
        int[] randomArray1 = new int[49];
        int[] outputNum = new int[7];
        int[] inputNum = new int[5];
        int[] Xarray = new int[49];
        int[] yarray = new int[49];
        List<Timer> Timerlist = new List<Timer>();
        List<int> myLists = new List<int>() { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        List<int> myLists1 = new List<int>() { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
        List<string> myLists2 = new List<string>() { "1", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "2", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "3", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "4", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "5", "6", "7", "8", "9" };
        string result;
        public lottery()
        {
            InitializeComponent();
        }
        public lottery(string strTextMsg)
        {
            InitializeComponent();
            textBox1.Text = strTextMsg;
        }

        public string TextBoxMsg
        {
            set
            {
                textBox1.Text = value;
            }
            get
            {
                return textBox1.Text;
            }
        }
        public string TextBoxMsg1
        {
            set
            {
                textBox2.Text = value;
            }
            get
            {
                return textBox2.Text;
            }
        }
        public string TextBoxMsg2
        {
            set
            {
                textBox3.Text = value;
            }
            get
            {
                return textBox3.Text;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Timerlist.Add(timer1);
            Timerlist.Add(timer2);
            Timerlist.Add(timer3);
            Timerlist.Add(timer4);
            Timerlist.Add(timer5);
            Timerlist.Add(timer6);
            Timerlist.Add(timer7);
            Timerlist.Add(timer8);
            Timerlist.Add(timer9);
            Timerlist.Add(timer10);
            Timerlist.Add(timer11);
            Timerlist.Add(timer12);
            Timerlist.Add(timer13);
            Timerlist.Add(timer14);
            Timerlist.Add(timer15);
            Timerlist.Add(timer16);
            Timerlist.Add(timer17);
            Timerlist.Add(timer18);
            Timerlist.Add(timer19);
            Timerlist.Add(timer20);
            Timerlist.Add(timer21);
            Timerlist.Add(timer22);
            Timerlist.Add(timer23);
            Timerlist.Add(timer24);
            Timerlist.Add(timer25);
            Timerlist.Add(timer26);
            Timerlist.Add(timer27);
            Timerlist.Add(timer28);
            Timerlist.Add(timer29);
            Timerlist.Add(timer30);
            Timerlist.Add(timer31);
            Timerlist.Add(timer32);
            Timerlist.Add(timer33);
            Timerlist.Add(timer34);
            Timerlist.Add(timer35);
            Timerlist.Add(timer36);
            Timerlist.Add(timer37);
            Timerlist.Add(timer38);
            Timerlist.Add(timer39);
            Timerlist.Add(timer40);
            Timerlist.Add(timer41);
            Timerlist.Add(timer42);
            Timerlist.Add(timer43);
            Timerlist.Add(timer44);
            Timerlist.Add(timer45);
            Timerlist.Add(timer46);
            Timerlist.Add(timer47);
            Timerlist.Add(timer48);
            Timerlist.Add(timer49);
            for(int i = 0; i < Timerlist.Count; i++)
            {
                Timerlist[i].Enabled = true;
            }

        }
        public string TextBoxMsg3
        {
            set
            {
                textBox4.Text = value;
            }
            get
            {
                return textBox4.Text;
            }
        }
        public string TextBoxMsg4
        {
            set
            {
                textBox5.Text = value;
            }
            get
            {
                return textBox5.Text;
            }
        }
        public void check()
        {
            textBox10.Enabled = false;
            textBox11.Enabled = false;
            textBox12.Enabled = false;
            textBox9.Enabled = false;
            textBox8.Enabled = false;
            textBox7.Enabled = false;
            textBox6.Enabled = false;
            int count = 0;
            int special = 0;
            inputNum[0]=int.Parse(textBox1.Text);
            inputNum[1]=int.Parse(textBox2.Text);
            inputNum[2]=int.Parse(textBox3.Text);
            inputNum[3]=int.Parse(textBox4.Text);
            inputNum[4]=int.Parse(textBox5.Text);
            outputNum[0] = int.Parse(textBox12.Text);
            outputNum[1] = int.Parse(textBox10.Text);
            outputNum[2] = int.Parse(textBox9.Text);
            outputNum[3] = int.Parse(textBox8.Text);
            outputNum[4] = int.Parse(textBox7.Text);
            outputNum[5] = int.Parse(textBox6.Text);
            int specialNum = int.Parse(textBox11.Text);
            if (Enumerable.SequenceEqual(inputNum, outputNum))
            {
                count++;
            }
            
            for(int i = 0; i < inputNum.Length; i++)
            {
                if (inputNum[i] == specialNum)
                {
                    special = 1;
                }
            }
            if (count == 2 && special == 1)
            {
                result = "柒獎";
            }
            else if (count ==3)
            {
                if (special == 1)
                {
                    result = "陸獎";
                }
                result = "普通";
            }else if (count == 4)
            {
                if (special == 1)
                {
                    result = "肆獎";
                }
                result = "伍獎";
            }
            else if (count == 5)
            {
                if (special == 1)
                {
                    result = "貳獎";
                }
                result = "參獎";
            }
            else if (count == 6)
            {
                result = "頭獎";
            }
            else
            {
                result = "再接再厲";
            }
            button1.Enabled = false;
        }
        private void lottery_Load(object sender, EventArgs e)
        {
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            textBox9.Clear();
            textBox8.Clear();
            textBox7.Clear();
            textBox6.Clear();
            imageload();
            int Num = 49;
            Random r = new Random();
            pb = new PictureBox[Num];
            for (int i = 0; i < Num; i++)
            {
                pb[i] = new System.Windows.Forms.PictureBox();
                pb[i].BorderStyle = BorderStyle.FixedSingle;
                randomArray[i] = r.Next(10, 260);
                randomArray1[i] = r.Next(20, 200);
                for (int j = 0; j < i; j++)
                {
                    while (randomArray[j] == randomArray[i])    //檢查是否與前面產生的數值發生重複，如果有就重新產生
                    {
                        j = 0;  //如有重複，將變數j設為0，再次檢查 (因為還是有重複的可能)
                        randomArray[i] = r.Next(10, 260);   //重新產生，存回陣列，亂數產生的範圍是1~9
                    }
                }
                for (int j = 0; j < i; j++)
                {
                    while (randomArray1[j] == randomArray1[i])    //檢查是否與前面產生的數值發生重複，如果有就重新產生
                    {
                        j = 0;  //如有重複，將變數j設為0，再次檢查 (因為還是有重複的可能)
                        randomArray1[i] = r.Next(20, 200);   //重新產生，存回陣列，亂數產生的範圍是1~9
                    }
                }
                pb[i].Location = new Point(randomArray[i], randomArray1[i]);
                Xarray[i] = r.Next(10, 220);
                yarray[i] = r.Next(15, 200);
                for (int j = 0; j < i; j++)
                {
                    while (Xarray[j] == Xarray[i])    //檢查是否與前面產生的數值發生重複，如果有就重新產生
                    {
                        j = 0;  //如有重複，將變數j設為0，再次檢查 (因為還是有重複的可能)
                        Xarray[i] = r.Next(10, 220);   //重新產生，存回陣列，亂數產生的範圍是1~9
                    }
                }
                for (int j = 0; j < i; j++)
                {
                    while (yarray[j] == yarray[i])    //檢查是否與前面產生的數值發生重複，如果有就重新產生
                    {
                        j = 0;  //如有重複，將變數j設為0，再次檢查 (因為還是有重複的可能)
                        yarray[i] = r.Next(15, 200);   //重新產生，存回陣列，亂數產生的範圍是1~9
                    }
                }
                pb[i].Top = yarray[i];
                pb[i].Left = Xarray[i];
                pb[i].Size = new Size(25, 25);
                panel2.Controls.Add(pb[i]);
                pb[i].Image = ig.Images[i];
                pb[i].Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom;
                System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
                path.AddEllipse(this.pb[i].ClientRectangle);
                Region reg = new Region(path);
                this.pb[i].Region = reg;

            }
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;

        }
        private void imageload()
        {
            ig.ImageSize = new Size(20, 20);
            DirectoryInfo di = new DirectoryInfo(Application.StartupPath + "\\Number");
            foreach (FileInfo fi in di.GetFiles())
            {
                if (fi.Name.ToUpper().EndsWith(".PNG"))
                {
                    ig.Images.Add(Image.FromFile(fi.FullName));
                }
            }

        }
        private void lottery_FormClosing(object sender, FormClosingEventArgs e)
        {
            MessageBox.Show("遊戲結束!");
            Application.Exit();
        }
        private void FirstElapsedVoid(int now,int BallX)
        {
            Random r = new Random();
            switch (myLists[now] % 2)
            {
                case 0:
                    if (textBox10.Text != "" && textBox9.Text != "" && textBox8.Text != "" && textBox7.Text != "" && textBox6.Text != "" && textBox12.Text != "" && textBox10.Text != "" && textBox11.Text != "")
                    {
                        foreach (var timer in Timerlist)
                        {
                            timer.Stop();
                        }
                        check();
                    }
                    //panel1.width=679 pictureBox.width=43 =>636
                    //panel1.height=382 pictureBox.width=39 =>353
                    if (pb[now].Left < panel2.Width - 30)
                    {
                        pb[now].Left = pb[now].Left + BallX;
                        for (int i = 0; i < 49; i++)
                        {
                            if (pb[now].Left - 3 == pb[i].Right && pb[now].Top == pb[i].Bottom || pb[now].Bottom == pb[i].Top && pb[now].Right == pb[i].Left - 3)
                            {
                                pb[now].Left += 5;
                                pb[i].Left -= 5;
                                pb[now].Top += 5;
                                pb[i].Top -= 5;
                            }
                            else
                            {
                                continue;
                            }
                        }
                    }
                    else if (pb[now].Top <= button4.Top + 30 && pb[now].Left >= button4.Left - 25)
                    {
                        panel2.Controls.Remove(pb[now]);
                        pb[now].Location = new Point(410, 16);
                        //pb[i].SizeMode = PictureBoxSizeMode.Zoom
                        pb[now].Top = 223;
                        pb[now].Left =r.Next(3,120);
                        pb[now].Size = new Size(23, 23);
                        panel1.Controls.Add(pb[now]);
                        pb[now].Image = ig.Images[now];
                        System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
                        path.AddEllipse(this.pb[now].ClientRectangle);
                        Region reg = new Region(path);
                        this.pb[now].Region = reg;
                        if (textBox10.Text == "")
                        {
                            textBox10.Text = myLists2[now];
                        }
                        else if (textBox9.Text == "")
                        {
                            textBox9.Text = myLists2[now];
                        }
                        else if (textBox8.Text == "")
                        {
                            textBox8.Text = myLists2[now];
                        }
                        else if (textBox7.Text == "")
                        {
                            textBox7.Text = myLists2[now];
                        }
                        else if (textBox6.Text == "")
                        {
                            textBox6.Text = myLists2[now];
                        }
                        else if (textBox12.Text == "")
                        {
                            textBox12.Text = myLists2[now];
                        }
                        else if (textBox11.Text == "")
                        {
                            textBox11.Text = myLists2[now];
                            foreach (var timer in Timerlist)
                            {
                                timer.Stop();
                            }
                            check();
                        }
                    }
                    else
                    {
                        myLists[now] = myLists[now] + 1;

                    }
                    break;
                case 1:
                    if (textBox10.Text != "" && textBox9.Text != "" && textBox8.Text != "" && textBox7.Text != "" && textBox6.Text != "" && textBox12.Text != "" && textBox10.Text != "" && textBox11.Text != "")
                    {
                        foreach (var timer in Timerlist)
                        {
                            timer.Stop();
                        }
                        check();
                    }
                    if (pb[now].Left > BallX)
                    {
                        pb[now].Left = pb[now].Left - BallX;
                        for (int i = 0; i < 49; i++)
                        {
                            if (pb[now].Left - 3 == pb[i].Right && pb[now].Top == pb[i].Bottom || pb[now].Bottom == pb[i].Top && pb[now].Right == pb[i].Left - 3)
                            {
                                pb[now].Left += 5;
                                pb[i].Left -= 5;
                                pb[now].Top += 5;
                                pb[i].Top -= 5;
                            }
                            else
                            {
                                continue;
                            }
                        }
                    }
                    else if (pb[now].Top <= button4.Top + 30 && pb[now].Left >= button4.Left - 25)
                    {
                        Timerlist[now].Stop();
                        panel2.Controls.Remove(pb[now]);
                        pb[now].Location = new Point(410, 16);
                        //pb[i].SizeMode = PictureBoxSizeMode.Zoom
                        pb[now].Top = 220;
                        pb[now].Left = r.Next(3, 120);
                        pb[now].Size = new Size(23, 23);
                        panel1.Controls.Add(pb[now]);
                        pb[now].Image = ig.Images[now];
                        System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
                        path.AddEllipse(this.pb[now].ClientRectangle);
                        Region reg = new Region(path);
                        this.pb[now].Region = reg;
                        while (pb[now].Right > panel1.Width - pb[now].Width)
                        {
                            pb[now].Left += 2;
                        }
                        if (textBox10.Text == "")
                        {
                            textBox10.Text = myLists2[now];
                        }
                        else if (textBox9.Text == "")
                        {
                            textBox9.Text = myLists2[now];
                        }
                        else if (textBox8.Text == "")
                        {
                            textBox8.Text = myLists2[now];
                        }
                        else if (textBox7.Text == "")
                        {
                            textBox7.Text = myLists2[now];
                        }
                        else if (textBox6.Text == "")
                        {
                            textBox6.Text = myLists2[now];
                        }
                        else if (textBox12.Text == "")
                        {
                            textBox12.Text = myLists2[now];
                        }
                        else if (textBox11.Text == "")
                        {
                            textBox11.Text = myLists2[now];
                            foreach (var timer in Timerlist)
                            {
                                timer.Stop();
                            }
                            check();
                        }
                    }
                    else
                    {
                        myLists[now] = myLists[now] - 1;

                    }

                    break;

            }
            switch (myLists1[now] % 2)
            {
                case 0:
                    if (textBox10.Text != "" && textBox9.Text != "" && textBox8.Text != "" && textBox7.Text != "" && textBox6.Text != "" && textBox12.Text != "" && textBox10.Text != "" && textBox11.Text != "")
                    {
                        foreach (var timer in Timerlist)
                        {
                            timer.Stop();
                        }
                        check();
                    }
                    BallX = r.Next(10, 25);
                    if (pb[now].Top < panel2.Height - 30)
                    {
                        pb[now].Top = pb[now].Top + BallX;
                        for (int i = 0; i < 49; i++)
                        {
                            if (pb[now].Left - 3 == pb[i].Right && pb[now].Top == pb[i].Bottom || pb[now].Bottom == pb[i].Top && pb[now].Right == pb[i].Left - 3)
                            {
                                pb[now].Left += 5;
                                pb[i].Left -= 5;
                                pb[now].Top += 5;
                                pb[i].Top -= 5;
                            }
                            else
                            {
                                continue;
                            }
                        }
                    }
                    else if (pb[now].Top <= button4.Top + 30 && pb[now].Left >= button4.Left - 25)
                    {
                        panel2.Controls.Remove(pb[now]);
                        Timerlist[now].Stop();
                        pb[now].Location = new Point(410, 16);
                        //pb[i].SizeMode = PictureBoxSizeMode.Zoom
                        pb[now].Top = 225;
                        pb[now].Left = r.Next(3, 120) ;
                        pb[now].Size = new Size(23, 23);
                        panel1.Controls.Add(pb[now]);
                        pb[now].Image = ig.Images[now];
                        System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
                        path.AddEllipse(this.pb[now].ClientRectangle);
                        Region reg = new Region(path);
                        this.pb[now].Region = reg;
                        while (pb[now].Right > panel1.Width - 30)
                        {
                            pb[now].Left += 2;
                        }
                        if (textBox10.Text == "")
                        {
                            textBox10.Text = myLists2[now];
                        }
                        else if (textBox9.Text == "")
                        {
                            textBox9.Text = myLists2[now];
                        }
                        else if (textBox8.Text == "")
                        {
                            textBox8.Text = myLists2[now];
                        }
                        else if (textBox7.Text == "")
                        {
                            textBox7.Text = myLists2[now];
                        }
                        else if (textBox6.Text == "")
                        {
                            textBox6.Text = myLists2[now];
                        }
                        else if (textBox12.Text == "")
                        {
                            textBox12.Text = myLists2[now];
                        }
                        else if (textBox11.Text == "")
                        {
                            textBox11.Text = myLists2[now];
                            foreach (var timer in Timerlist)
                            {
                                timer.Stop();
                            }
                            check();
                        }

                    }
                    else
                    {
                        myLists1[now] = myLists1[now] + 1;
                    }

                    break;
                case 1:
                    if (textBox10.Text != "" && textBox9.Text != "" && textBox8.Text != "" && textBox7.Text != "" && textBox6.Text != "" && textBox12.Text != "" && textBox10.Text != "" && textBox11.Text != "")
                    {
                        foreach (var timer in Timerlist)
                        {
                            timer.Stop();
                        }
                        check();
                    }
                    if (pb[now].Top > BallX)
                    {
                        pb[now].Top = pb[now].Top - BallX;
                        for (int i = 0; i < 49; i++)
                        {
                            if (pb[now].Left - 3 == pb[i].Right && pb[now].Top == pb[i].Bottom || pb[now].Bottom == pb[i].Top && pb[now].Right == pb[i].Left - 3)
                            {
                                pb[now].Left += 5;
                                pb[i].Left -= 5;
                                pb[now].Top += 5;
                                pb[i].Top -= 5;
                            }
                            else
                            {
                                continue;
                            }
                        }
                    }
                    else if (pb[now].Top <= button4.Top + 30 && pb[now].Left >= button4.Left - 25)
                    {
                        panel2.Controls.Remove(pb[now]);
                        Timerlist[now].Stop();
                        pb[now].Location = new Point(410, 16);
                        pb[now].Top = 230;
                        pb[now].Left = r.Next(3, 120); 
                        pb[now].Size = new Size(23, 23);
                        panel1.Controls.Add(pb[now]);
                        pb[now].Image = ig.Images[now];
                        System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
                        path.AddEllipse(this.pb[now].ClientRectangle);
                        Region reg = new Region(path);
                        this.pb[now].Region = reg;
                        while (pb[now].Right > panel1.Width - pb[now].Width)
                        {
                            pb[now].Left += 2;
                        }
                        if (textBox10.Text == "")
                        {
                            textBox10.Text = myLists2[now];
                        }
                        else if (textBox9.Text == "")
                        {
                            textBox9.Text = myLists2[now];
                        }
                        else if (textBox8.Text == "")
                        {
                            textBox8.Text = myLists2[now];
                        }
                        else if (textBox7.Text == "")
                        {
                            textBox7.Text = myLists2[now];
                        }
                        else if (textBox6.Text == "")
                        {
                            textBox6.Text = myLists2[now];
                        }
                        else if (textBox12.Text == "")
                        {
                            textBox12.Text = myLists2[now];
                        }
                        else if (textBox11.Text == "")
                        {
                            textBox11.Text = myLists2[now];
                            foreach (var timer in Timerlist)
                            {
                                timer.Stop();
                            }
                            check();
                        }

                    }
                    else
                    {
                        myLists1[now] = myLists1[now] - 1;
                    }

                    break;
            }
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            
            int y= r.Next(10, 25);
            FirstElapsedVoid(3,y);
            
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(4,y);
        }

        private void timer6_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(5,y);
        }

        private void timer7_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(6,y);
        }

        private void timer8_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(7,y);
        }

        private void timer9_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(8,y);
        }

        private void timer10_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(9,y);
        }

        private void timer11_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(10,y);
        }

        private void timer12_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(11,y);
        }

        private void timer13_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(12,y);
        }

        private void timer40_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(39,y);
        }

        private void timer14_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(13,y);
        }

        private void timer15_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(14,y);
        }

        private void timer16_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(15,y);
        }

        private void timer17_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(16,y);
        }

        private void timer18_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(17,y);
        }

        private void timer19_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(18,y);
        }

        private void timer20_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(19,y);
        }

        private void timer21_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(20,y);
        }

        private void timer22_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(21,y);
        }

        private void timer23_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(22,y);
        }

        private void timer24_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(23,y);
        }

        private void timer25_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(24,y);
        }

        private void timer26_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(25,y);
        }

        private void timer27_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(26,y);
        }

        private void timer28_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(27,y);
        }

        private void timer29_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(28,y);
        }

        private void timer30_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(29,y);
        }

        private void timer31_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(30,y);
        }

        private void timer32_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(31,y);
        }

        private void timer33_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(32,y);

        }

        private void timer34_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(33,y);
        }

        private void timer35_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(34,y);
        }

        private void timer36_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(35,y);
        }

        private void timer37_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(36,y);
        }

        private void timer38_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(37,y);
        }

        private void timer39_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(38,y);
        }

        private void timer41_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(40,y);
        }

        private void timer42_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(41,y);
        }

        private void timer43_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(42,y);
        }

        private void timer44_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(43,y);
        }

        private void timer45_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(44,y);
        }

        private void timer46_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(45,y);
        }

        private void timer47_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(46,y);
        }

        private void timer48_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(47,y);
        }

        private void timer49_Tick(object sender, EventArgs e)
        {
            int y = r.Next(10, 25);
            FirstElapsedVoid(48,y);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            show obj = new show();
            obj.TextMsg = result;
            this.result = obj.TextMsg;//從form2取值設定到form1
            this.Visible = false;
            obj.Visible = true;
        }
    }
}



