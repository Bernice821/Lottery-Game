﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A107223007_Lottery
{
    public partial class show : Form
    {
        

        public show()
        {
            InitializeComponent();
        }
        public string TextMsg
        {
            set
            {
                textBox1.Text = value;
            }
            get
            {
                return textBox1.Text;
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("遊戲結束!");
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 obj = new Form2();
            this.Visible = false;
            obj.Visible = true;
        }

        private void show_Load(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
        }

        private void show_FormClosing(object sender, FormClosingEventArgs e)
        {
            MessageBox.Show("遊戲結束!");
            Application.Exit();
        }
    }
}
