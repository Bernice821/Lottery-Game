﻿namespace A107223007_Lottery
{
    partial class lottery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.timer5 = new System.Windows.Forms.Timer(this.components);
            this.timer6 = new System.Windows.Forms.Timer(this.components);
            this.timer7 = new System.Windows.Forms.Timer(this.components);
            this.timer8 = new System.Windows.Forms.Timer(this.components);
            this.timer9 = new System.Windows.Forms.Timer(this.components);
            this.timer10 = new System.Windows.Forms.Timer(this.components);
            this.timer11 = new System.Windows.Forms.Timer(this.components);
            this.timer12 = new System.Windows.Forms.Timer(this.components);
            this.timer13 = new System.Windows.Forms.Timer(this.components);
            this.timer14 = new System.Windows.Forms.Timer(this.components);
            this.timer15 = new System.Windows.Forms.Timer(this.components);
            this.timer16 = new System.Windows.Forms.Timer(this.components);
            this.timer17 = new System.Windows.Forms.Timer(this.components);
            this.timer18 = new System.Windows.Forms.Timer(this.components);
            this.timer19 = new System.Windows.Forms.Timer(this.components);
            this.timer20 = new System.Windows.Forms.Timer(this.components);
            this.timer21 = new System.Windows.Forms.Timer(this.components);
            this.timer22 = new System.Windows.Forms.Timer(this.components);
            this.timer23 = new System.Windows.Forms.Timer(this.components);
            this.timer24 = new System.Windows.Forms.Timer(this.components);
            this.timer25 = new System.Windows.Forms.Timer(this.components);
            this.timer26 = new System.Windows.Forms.Timer(this.components);
            this.timer27 = new System.Windows.Forms.Timer(this.components);
            this.timer28 = new System.Windows.Forms.Timer(this.components);
            this.timer29 = new System.Windows.Forms.Timer(this.components);
            this.timer30 = new System.Windows.Forms.Timer(this.components);
            this.timer31 = new System.Windows.Forms.Timer(this.components);
            this.timer32 = new System.Windows.Forms.Timer(this.components);
            this.timer33 = new System.Windows.Forms.Timer(this.components);
            this.timer34 = new System.Windows.Forms.Timer(this.components);
            this.timer35 = new System.Windows.Forms.Timer(this.components);
            this.timer36 = new System.Windows.Forms.Timer(this.components);
            this.timer37 = new System.Windows.Forms.Timer(this.components);
            this.timer38 = new System.Windows.Forms.Timer(this.components);
            this.timer39 = new System.Windows.Forms.Timer(this.components);
            this.timer40 = new System.Windows.Forms.Timer(this.components);
            this.timer41 = new System.Windows.Forms.Timer(this.components);
            this.timer42 = new System.Windows.Forms.Timer(this.components);
            this.timer43 = new System.Windows.Forms.Timer(this.components);
            this.timer44 = new System.Windows.Forms.Timer(this.components);
            this.timer45 = new System.Windows.Forms.Timer(this.components);
            this.timer46 = new System.Windows.Forms.Timer(this.components);
            this.timer47 = new System.Windows.Forms.Timer(this.components);
            this.timer48 = new System.Windows.Forms.Timer(this.components);
            this.timer49 = new System.Windows.Forms.Timer(this.components);
            this.button2 = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.AliceBlue;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(411, 15);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(249, 382);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.AliceBlue;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.button4);
            this.panel2.Location = new System.Drawing.Point(12, 16);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(398, 381);
            this.panel2.TabIndex = 0;
            // 
            // button4
            // 
            this.button4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.button4.BackColor = System.Drawing.Color.SteelBlue;
            this.button4.Location = new System.Drawing.Point(308, -2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(88, 24);
            this.button4.TabIndex = 1;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.BackColor = System.Drawing.Color.AliceBlue;
            this.button1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.Location = new System.Drawing.Point(131, 565);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 34);
            this.button1.TabIndex = 1;
            this.button1.Text = "開球";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(3, 512);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 23);
            this.label1.TabIndex = 2;
            this.label1.Text = "您選的號碼:";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("微軟正黑體", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox1.Location = new System.Drawing.Point(131, 498);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(50, 43);
            this.textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("微軟正黑體", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox2.Location = new System.Drawing.Point(205, 498);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(50, 43);
            this.textBox2.TabIndex = 4;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("微軟正黑體", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox3.Location = new System.Drawing.Point(279, 498);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(50, 43);
            this.textBox3.TabIndex = 5;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("微軟正黑體", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox4.Location = new System.Drawing.Point(359, 498);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(50, 43);
            this.textBox4.TabIndex = 6;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("微軟正黑體", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox5.Location = new System.Drawing.Point(437, 498);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(50, 43);
            this.textBox5.TabIndex = 7;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("微軟正黑體", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox6.Location = new System.Drawing.Point(437, 433);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(50, 43);
            this.textBox6.TabIndex = 13;
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("微軟正黑體", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox7.Location = new System.Drawing.Point(359, 433);
            this.textBox7.Multiline = true;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(50, 43);
            this.textBox7.TabIndex = 12;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("微軟正黑體", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox8.Location = new System.Drawing.Point(279, 433);
            this.textBox8.Multiline = true;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(50, 43);
            this.textBox8.TabIndex = 11;
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("微軟正黑體", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox9.Location = new System.Drawing.Point(205, 433);
            this.textBox9.Multiline = true;
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(50, 43);
            this.textBox9.TabIndex = 10;
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("微軟正黑體", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox10.Location = new System.Drawing.Point(131, 433);
            this.textBox10.Multiline = true;
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(50, 43);
            this.textBox10.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(16, 447);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 23);
            this.label2.TabIndex = 8;
            this.label2.Text = "開獎號:";
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.Color.FloralWhite;
            this.textBox11.Font = new System.Drawing.Font("微軟正黑體", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox11.Location = new System.Drawing.Point(593, 433);
            this.textBox11.Multiline = true;
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(50, 43);
            this.textBox11.TabIndex = 15;
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("微軟正黑體", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox12.Location = new System.Drawing.Point(515, 433);
            this.textBox12.Multiline = true;
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(50, 43);
            this.textBox12.TabIndex = 14;
            // 
            // button3
            // 
            this.button3.AutoSize = true;
            this.button3.BackColor = System.Drawing.Color.SteelBlue;
            this.button3.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button3.Location = new System.Drawing.Point(437, 565);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(111, 34);
            this.button3.TabIndex = 17;
            this.button3.Text = "離開";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 10;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Interval = 10;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // timer4
            // 
            this.timer4.Interval = 10;
            this.timer4.Tick += new System.EventHandler(this.timer4_Tick);
            // 
            // timer5
            // 
            this.timer5.Interval = 10;
            this.timer5.Tick += new System.EventHandler(this.timer5_Tick);
            // 
            // timer6
            // 
            this.timer6.Interval = 10;
            this.timer6.Tick += new System.EventHandler(this.timer6_Tick);
            // 
            // timer7
            // 
            this.timer7.Interval = 10;
            this.timer7.Tick += new System.EventHandler(this.timer7_Tick);
            // 
            // timer8
            // 
            this.timer8.Interval = 10;
            this.timer8.Tick += new System.EventHandler(this.timer8_Tick);
            // 
            // timer9
            // 
            this.timer9.Interval = 10;
            this.timer9.Tick += new System.EventHandler(this.timer9_Tick);
            // 
            // timer10
            // 
            this.timer10.Interval = 10;
            this.timer10.Tick += new System.EventHandler(this.timer10_Tick);
            // 
            // timer11
            // 
            this.timer11.Interval = 10;
            this.timer11.Tick += new System.EventHandler(this.timer11_Tick);
            // 
            // timer12
            // 
            this.timer12.Interval = 10;
            this.timer12.Tick += new System.EventHandler(this.timer12_Tick);
            // 
            // timer13
            // 
            this.timer13.Interval = 10;
            this.timer13.Tick += new System.EventHandler(this.timer13_Tick);
            // 
            // timer14
            // 
            this.timer14.Interval = 10;
            this.timer14.Tick += new System.EventHandler(this.timer14_Tick);
            // 
            // timer15
            // 
            this.timer15.Interval = 10;
            this.timer15.Tick += new System.EventHandler(this.timer15_Tick);
            // 
            // timer16
            // 
            this.timer16.Interval = 10;
            this.timer16.Tick += new System.EventHandler(this.timer16_Tick);
            // 
            // timer17
            // 
            this.timer17.Interval = 10;
            this.timer17.Tick += new System.EventHandler(this.timer17_Tick);
            // 
            // timer18
            // 
            this.timer18.Interval = 10;
            this.timer18.Tick += new System.EventHandler(this.timer18_Tick);
            // 
            // timer19
            // 
            this.timer19.Interval = 10;
            this.timer19.Tick += new System.EventHandler(this.timer19_Tick);
            // 
            // timer20
            // 
            this.timer20.Interval = 10;
            this.timer20.Tick += new System.EventHandler(this.timer20_Tick);
            // 
            // timer21
            // 
            this.timer21.Interval = 10;
            this.timer21.Tick += new System.EventHandler(this.timer21_Tick);
            // 
            // timer22
            // 
            this.timer22.Interval = 10;
            this.timer22.Tick += new System.EventHandler(this.timer22_Tick);
            // 
            // timer23
            // 
            this.timer23.Interval = 10;
            this.timer23.Tick += new System.EventHandler(this.timer23_Tick);
            // 
            // timer24
            // 
            this.timer24.Interval = 10;
            this.timer24.Tick += new System.EventHandler(this.timer24_Tick);
            // 
            // timer25
            // 
            this.timer25.Interval = 10;
            this.timer25.Tick += new System.EventHandler(this.timer25_Tick);
            // 
            // timer26
            // 
            this.timer26.Interval = 10;
            this.timer26.Tick += new System.EventHandler(this.timer26_Tick);
            // 
            // timer27
            // 
            this.timer27.Interval = 10;
            this.timer27.Tick += new System.EventHandler(this.timer27_Tick);
            // 
            // timer28
            // 
            this.timer28.Interval = 10;
            this.timer28.Tick += new System.EventHandler(this.timer28_Tick);
            // 
            // timer29
            // 
            this.timer29.Interval = 10;
            this.timer29.Tick += new System.EventHandler(this.timer29_Tick);
            // 
            // timer30
            // 
            this.timer30.Interval = 10;
            this.timer30.Tick += new System.EventHandler(this.timer30_Tick);
            // 
            // timer31
            // 
            this.timer31.Interval = 10;
            this.timer31.Tick += new System.EventHandler(this.timer31_Tick);
            // 
            // timer32
            // 
            this.timer32.Interval = 10;
            this.timer32.Tick += new System.EventHandler(this.timer32_Tick);
            // 
            // timer33
            // 
            this.timer33.Interval = 10;
            this.timer33.Tick += new System.EventHandler(this.timer33_Tick);
            // 
            // timer34
            // 
            this.timer34.Interval = 10;
            this.timer34.Tick += new System.EventHandler(this.timer34_Tick);
            // 
            // timer35
            // 
            this.timer35.Interval = 10;
            this.timer35.Tick += new System.EventHandler(this.timer35_Tick);
            // 
            // timer36
            // 
            this.timer36.Interval = 10;
            this.timer36.Tick += new System.EventHandler(this.timer36_Tick);
            // 
            // timer37
            // 
            this.timer37.Interval = 10;
            this.timer37.Tick += new System.EventHandler(this.timer37_Tick);
            // 
            // timer38
            // 
            this.timer38.Interval = 10;
            this.timer38.Tick += new System.EventHandler(this.timer38_Tick);
            // 
            // timer39
            // 
            this.timer39.Interval = 10;
            this.timer39.Tick += new System.EventHandler(this.timer39_Tick);
            // 
            // timer40
            // 
            this.timer40.Interval = 10;
            this.timer40.Tick += new System.EventHandler(this.timer40_Tick);
            // 
            // timer41
            // 
            this.timer41.Interval = 10;
            this.timer41.Tick += new System.EventHandler(this.timer41_Tick);
            // 
            // timer42
            // 
            this.timer42.Interval = 10;
            this.timer42.Tick += new System.EventHandler(this.timer42_Tick);
            // 
            // timer43
            // 
            this.timer43.Interval = 10;
            this.timer43.Tick += new System.EventHandler(this.timer43_Tick);
            // 
            // timer44
            // 
            this.timer44.Interval = 10;
            this.timer44.Tick += new System.EventHandler(this.timer44_Tick);
            // 
            // timer45
            // 
            this.timer45.Interval = 10;
            this.timer45.Tick += new System.EventHandler(this.timer45_Tick);
            // 
            // timer46
            // 
            this.timer46.Interval = 10;
            this.timer46.Tick += new System.EventHandler(this.timer46_Tick);
            // 
            // timer47
            // 
            this.timer47.Interval = 10;
            this.timer47.Tick += new System.EventHandler(this.timer47_Tick);
            // 
            // timer48
            // 
            this.timer48.Interval = 10;
            this.timer48.Tick += new System.EventHandler(this.timer48_Tick);
            // 
            // timer49
            // 
            this.timer49.Interval = 10;
            this.timer49.Tick += new System.EventHandler(this.timer49_Tick);
            // 
            // button2
            // 
            this.button2.AutoSize = true;
            this.button2.BackColor = System.Drawing.Color.AliceBlue;
            this.button2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button2.Location = new System.Drawing.Point(279, 565);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(111, 34);
            this.button2.TabIndex = 18;
            this.button2.Text = "結果";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // lottery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(672, 611);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel1);
            this.Name = "lottery";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "lottery";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.lottery_FormClosing);
            this.Load += new System.EventHandler(this.lottery_Load);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.Timer timer5;
        private System.Windows.Forms.Timer timer6;
        private System.Windows.Forms.Timer timer7;
        private System.Windows.Forms.Timer timer8;
        private System.Windows.Forms.Timer timer9;
        private System.Windows.Forms.Timer timer10;
        private System.Windows.Forms.Timer timer11;
        private System.Windows.Forms.Timer timer12;
        private System.Windows.Forms.Timer timer13;
        private System.Windows.Forms.Timer timer14;
        private System.Windows.Forms.Timer timer15;
        private System.Windows.Forms.Timer timer16;
        private System.Windows.Forms.Timer timer17;
        private System.Windows.Forms.Timer timer18;
        private System.Windows.Forms.Timer timer19;
        private System.Windows.Forms.Timer timer20;
        private System.Windows.Forms.Timer timer21;
        private System.Windows.Forms.Timer timer22;
        private System.Windows.Forms.Timer timer23;
        private System.Windows.Forms.Timer timer24;
        private System.Windows.Forms.Timer timer25;
        private System.Windows.Forms.Timer timer26;
        private System.Windows.Forms.Timer timer27;
        private System.Windows.Forms.Timer timer28;
        private System.Windows.Forms.Timer timer29;
        private System.Windows.Forms.Timer timer30;
        private System.Windows.Forms.Timer timer31;
        private System.Windows.Forms.Timer timer32;
        private System.Windows.Forms.Timer timer33;
        private System.Windows.Forms.Timer timer34;
        private System.Windows.Forms.Timer timer35;
        private System.Windows.Forms.Timer timer36;
        private System.Windows.Forms.Timer timer37;
        private System.Windows.Forms.Timer timer38;
        private System.Windows.Forms.Timer timer39;
        private System.Windows.Forms.Timer timer40;
        internal System.Windows.Forms.Panel panel1;
        internal System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Timer timer41;
        private System.Windows.Forms.Timer timer42;
        private System.Windows.Forms.Timer timer43;
        private System.Windows.Forms.Timer timer44;
        private System.Windows.Forms.Timer timer45;
        private System.Windows.Forms.Timer timer46;
        private System.Windows.Forms.Timer timer47;
        private System.Windows.Forms.Timer timer48;
        private System.Windows.Forms.Timer timer49;
        private System.Windows.Forms.Button button2;
    }
}